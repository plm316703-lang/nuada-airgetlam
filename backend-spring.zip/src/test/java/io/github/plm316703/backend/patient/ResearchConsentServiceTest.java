package io.github.plm316703.backend.patient;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import io.github.plm316703.backend.user.Role;
import io.github.plm316703.backend.user.User;
import io.github.plm316703.backend.user.UserRepository;

/**
 * 연구 동의환 환자의 철회하면 배정이 지워지고 
 * 없는 id로 철회를 요청하면 거절하고, 한번도 동의한적 없으면, 철회도 거절한다 
 */

@SpringBootTest 
@Transactional 
public class ResearchConsentServiceTest {

    @Autowired ResearchConsentService researchConsentService;   //검사 대상 
    @Autowired ResearcherAssignmentRepository researcherAssignmentRepository; //검사 확인용
    @Autowired UserRepository userRepository; //준비물 만들기용
    @Autowired PatientRepository patientRepository;//환자 

    @Test 
    @DisplayName ("동의환 환자는 철회하면 배정이 지워진다.")
    void deleteSuccess(){
        //given : 연구에 철회한 환자 
        User patientUser = userRepository.save(
            new User("patient@test.com", "1234", "테스트환자", Role.PATIENT));
        
    }
    
}
